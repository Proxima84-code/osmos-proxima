import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";
import cheerio from "cheerio";
import OpenAI from "openai";
import validUrl from "valid-url";
import dns from "dns/promises";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Resolve __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Global middleware
app.use(express.json());
app.use(cors());
app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        "img-src": ["'self'", "data:"],
      },
    },
  })
);

// Rate limit: 30 requests / minute / IP
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
});
app.use(limiter);

// Static assets
app.use("/styles", express.static(path.join(__dirname, "styles")));
app.get("/", (_, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Private IP ranges for SSRF protection
const PRIVATE_IP_RANGES = [
  [/^127\./], // loopback
  [/^10\./], // 10.0.0.0 – 10.255.255.255
  [/^192\.168\./], // 192.168.0.0 – 192.168.255.255
  [/^172\.(1[6-9]|2\d|3[0-1])\./], // 172.16.0.0 – 172.31.255.255
  [/^0\./], // 0.0.0.0/8
  [/^::1$/], // IPv6 loopback
];

function isPrivateIp(ip) {
  return PRIVATE_IP_RANGES.some(([re]) => re.test(ip));
}

// Fetch HTML with retries and SSRF protection
async function fetchHtml(targetUrl, retries = 2) {
  try {
    const url = new URL(targetUrl);
    if (!["http:", "https:"].includes(url.protocol)) {
      throw new Error("Only HTTP(S) protocols are supported.");
    }

    const { address } = await dns.lookup(url.hostname);
    if (isPrivateIp(address)) {
      throw new Error("Private IP addresses are not supported.");
    }

    const res = await axios.get(targetUrl, {
      timeout: 15000,
      headers: { "User-Agent": "Mozilla/5.0 (ProximaSEO Audit)" },
      maxRedirects: 5,
    });
    return res.data;
  } catch (err) {
    if (retries > 0) {
      await new Promise((r) => setTimeout(r, 1000));
      return fetchHtml(targetUrl, retries - 1);
    }
    throw new Error("Failed to fetch page: " + err.message);
  }
}

// Analyze SEO metrics from HTML
function analyzeSEO(html) {
  const $ = cheerio.load(html);
  const text = $("body").text();
  const words = text.split(/\s+/).filter(Boolean).length;
  const totalImages = $("img").length;
  const imagesWithAlt = $("img[alt]").length;
  const altRatio = totalImages ? Math.round((imagesWithAlt / totalImages) * 100) : 100;

  return {
    title: $("title").text().trim(),
    description: $("meta[name='description']").attr("content") || "",
    h1: $("h1").first().text().trim(),
    headings: $("h1,h2,h3").map((_, el) => $(el).text().trim()).get(),
    words,
    imagesWithAlt,
    totalImages,
    altRatio,
  };
}

// Calculate a simple SEO score
function calcScore({ words, altRatio, description, h1 }) {
  let score = 100;
  if (words < 300) score -= 10;
  if (altRatio < 60) score -= 10;
  if (!description) score -= 10;
  if (!h1) score -= 10;
  return Math.max(score, 0);
}

// Generate AI recommendations via OpenAI
async function aiRecommendations(analysis, score) {
  const prompt = \`The page has a score of \${score}/100. Analysis:
\${JSON.stringify(
    analysis,
    null,
    2
  )}

List the top-priority SEO improvements in Polish.\`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
  });

  return completion.choices[0].message.content.trim();
}

// Main audit route
app.post("/audit", async (req, res) => {
  const { url } = req.body;
  if (!url || !validUrl.isWebUri(url)) {
    return res.status(400).json({ error: "Invalid URL" });
  }

  try {
    const html = await fetchHtml(url);
    const analysis = analyzeSEO(html);
    const score = calcScore(analysis);
    const rec = await aiRecommendations(analysis, score);
    res.json({ score, analysis, recommendations: rec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(\`🚀 Server running on http://localhost:\${PORT}\`);
});