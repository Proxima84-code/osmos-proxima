# Osmoza Proxima

Osmoza Proxima to narzędzie do automatycznego audytu SEO stron internetowych z wykorzystaniem AI. 

## Funkcjonalności

- Analiza liczby słów, nagłówków (h1, h2, h3), meta description.
- Sprawdzenie obrazków pod kątem atrybutów alt i obliczenie ich udziału.
- Proste przydzielanie punktacji (0–100).
- Rekomendacje poprawek SEO generowane przez model OpenAI w języku polskim.

## Instalacja

1. Sklonuj repozytorium.
2. Utwórz plik `.env` z kluczem API:
   ```
   OPENAI_API_KEY=your_api_key_here
   ```
3. Uruchom:
   ```bash
   npm install
   npm start
   ```

## Użycie

1. Otwórz przeglądarkę i przejdź do `http://localhost:3000`.
2. Wprowadź URL strony i kliknij **Analizuj**.
3. Odczytaj wynik i rekomendacje.

## Plany na przyszłość

- Obsługa batch audit.
- Zaawansowana analiza wydajności i dostępności.
